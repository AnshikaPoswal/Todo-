<div>
    <?php if(session()->has('success')): ?>
        <?php echo e(session()->get('success')); ?>

    <?php elseif($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div><?php /**PATH D:\tesmo_1\tesmo\resources\views/components/alert.blade.php ENDPATH**/ ?>